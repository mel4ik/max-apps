const API = import.meta.env.VITE_API_BASE || '/api';

function headers() {
  const h = { 'Content-Type': 'application/json' };
  if (window.WebApp?.initData) h['X-Max-Init-Data'] = window.WebApp.initData;
  return h;
}

async function req(path, opts = {}) {
  const r = await fetch(API + path, { headers: headers(), ...opts });
  if (!r.ok) {
    const d = await r.json().catch(() => null);
    throw new Error(d?.detail || `Ошибка ${r.status}`);
  }
  return r.json();
}

// GET /api/cards → { cards: [...] }
export async function getCards() {
  const data = await req('/cards');
  return data.cards || [];
}

// POST /api/cards { card_pan }
export function addCard(pan) {
  return req('/cards', { method: 'POST', body: JSON.stringify({ card_pan: pan }) });
}

// DELETE /api/cards/{id}
export function deleteCard(id) {
  return req(`/cards/${id}`, { method: 'DELETE' });
}

// GET /api/cards/{id}/info → raw Korona response
export function getCardInfo(id, force = false) {
  return req(`/cards/${id}/info${force ? '?force=true' : ''}`);
}

// GET /api/cards/{id}/trips → { data: [...], paging: {...} }
export function getTrips(id, page = 0, size = 20) {
  return req(`/cards/${id}/trips?page=${page}&size=${size}`);
}

// GET /api/cards/{id}/replenishments → { data: [...], paging: {...} }
export function getReplenishments(id, page = 0, size = 20) {
  return req(`/cards/${id}/replenishments?page=${page}&size=${size}`);
}

export function health() { return req('/health'); }

/**
 * Парсит сырой ответ GET /v2/cards/{pan} в плоский объект для UI.
 * Реальная структура:
 *   card_info.card_money_value → баланс (копейки) внутри counter_money
 *   counter_trips → null для кошелька
 *   transport_application.start_date / expiration_date
 *   ticket_rule.ticket_description → "Проездной ЧасПик"
 *   extra_services → { abonement:[], counter:[], money_counter:[], day_counter:[] }
 */
export function parseCardStatus(status) {
  if (!status) return null;

  const ci = status.card_info || {};
  const ta = status.transport_application || {};
  const counter = ta.counter || {};
  const ct = counter.counter_trips;  // null для кошелька
  const cm = counter.counter_money || {};
  const tr = status.ticket_rule || {};
  const es = status.extra_services || {};

  // Баланс: card_money_value в копейках (124300 = 1243₽)
  const bal = cm.card_money_value || 0;

  // Поездки: counter_trips может быть null или объект {counter_value: N}
  const tripsVal = ct ? ct.counter_value : null;
  const tripsMax = ct ? ct.counter_max_value : null;

  // Определяем kind
  let kind = 'purse'; // по умолчанию — кошелёк
  if (tripsVal != null && tripsVal > 0) {
    kind = 'counter';
  }
  // Абонемент: есть даты, нет денег и поездок
  if (ta.start_date && ta.expiration_date && !bal && !tripsVal) {
    kind = 'abonement';
  }

  // Собираем доступные услуги для покупки из extra_services
  const svcs = [
    ...(es.abonement || []),
    ...(es.counter || []),
    ...(es.money_counter || []),
    ...(es.day_counter || []),
  ];

  return {
    stop: ci.is_in_stoplist || false,
    stopStatus: ci.stop_list_status,
    bal,                              // копейки
    currency: cm.counter_money_currency, // 643=RUB
    trips: tripsVal || 0,
    tripsMax,
    tripsEnd: ta.expiration_date || null,
    abStart: ta.start_date || null,
    abEnd: ta.expiration_date || null,
    kind,
    label: tr.ticket_description || tr.short_description || (
      kind === 'purse' ? 'Электронный кошелёк' :
      kind === 'counter' ? 'Пакет поездок' : 'Абонемент'
    ),
    svcs,
    stale: status._stale || false,
    source: status._source || 'unknown',
    cardImgUri: ci.card_img_uri || null,
  };
}
