import React, { useState, useEffect, useCallback } from 'react';
import { useMaxBridge } from './hooks/useMaxBridge';
import * as api from './api/client';
import CardList from './pages/CardList';
import AddCard from './pages/AddCard';
import CardDetail from './pages/CardDetail';
import TopUp from './pages/TopUp';
import BuyService from './pages/BuyService';
import YooKassa from './pages/YooKassa';
import Result from './pages/Result';
import Admin from './pages/Admin';

export default function App() {
  const bridge = useMaxBridge();
  const [scr, setScr]     = useState('cards');
  const [cards, setCards]  = useState([]);   // raw items from GET /api/cards
  const [card, setCard]    = useState(null); // selected raw card + parsed status
  const [amt, setAmt]      = useState(0);
  const [svc, setSvc]      = useState(null);
  const [loading, setLoad] = useState(true);
  const [error, setError]  = useState(null);

  // ─── Загрузка карт ───
  const fetchCards = useCallback(async () => {
    setLoad(true); setError(null);
    try {
      const items = await api.getCards();
      // Каждый item имеет { id, card_pan, region, ticket_description, is_replenishable, status:{...} }
      // Парсим status в плоские поля для UI
      const enriched = items.map(item => ({
        ...item,
        n: item.card_pan,
        parsed: api.parseCardStatus(item.status),
      }));
      setCards(enriched);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoad(false);
    }
  }, []);

  useEffect(() => { if (bridge.ready) fetchCards(); }, [bridge.ready, fetchCards]);

  // ─── MAX BackButton ───
  useEffect(() => {
    const backMap = {
      add:'cards', det:'cards', top:'det',
      buy:'det', pay:'det', adm:'cards'
    };
    const target = backMap[scr];
    if (!target) return;
    return bridge.back(true, () => setScr(target));
  }, [scr, bridge]);

  // ─── Добавление карты ───
  function handleAdded(pan) {
    api.addCard(pan).then(nc => {
      // nc = { id, card_pan, region, ticket_description, status }
      const enriched = {
        ...nc,
        n: nc.card_pan,
        parsed: api.parseCardStatus(nc.status),
      };
      setCards(prev => [...prev, enriched]);
      bridge.success();
    }).catch(e => {
      bridge.error();
    });
    setScr('cards');
  }

  // ─── Выбор карты: подгружаем свежий info ───
  async function handleSelect(c) {
    setCard(c);
    setScr('det');
    try {
      const info = await api.getCardInfo(c.id);
      const parsed = api.parseCardStatus(info);
      setCard(prev => ({
        ...prev,
        status: info,
        parsed: parsed || prev.parsed,
      }));
    } catch {}
  }

  // ─── Shell ───
  return (
    <div style={{
      maxWidth:480, margin:'0 auto',
      background:'#F4F6FA', minHeight:'100dvh',
      fontFamily:"'Manrope',sans-serif", color:'#0F1729',
      display:'flex', flexDirection:'column'
    }}>
      <div style={{ flex:1, overflowY:'auto', overflowX:'hidden' }}>
        {scr === 'cards' && (
          <CardList
            cards={cards} loading={loading} error={error}
            onRefresh={fetchCards}
            onSelect={handleSelect}
            onAdd={() => setScr('add')}
          />
        )}
        {scr === 'add' && (
          <AddCard
            onBack={() => setScr('cards')}
            onAdded={handleAdded}
            bridge={bridge}
          />
        )}
        {scr === 'det' && card && (
          <CardDetail
            card={card}
            onBack={() => { setScr('cards'); fetchCards(); }}
            onTopUp={() => setScr('top')}
            onBuyService={() => setScr('buy')}
            bridge={bridge}
          />
        )}
        {scr === 'top' && card && (
          <TopUp
            card={card}
            onBack={() => setScr('det')}
            onPay={amount => { setAmt(amount); setSvc(null); setScr('pay'); }}
          />
        )}
        {scr === 'buy' && card && (
          <BuyService
            card={card}
            onBack={() => setScr('det')}
            onPay={(amount, service) => { setAmt(amount); setSvc(service); setScr('pay'); }}
          />
        )}
        {scr === 'pay' && card && (
          <YooKassa
            card={card} amt={amt} svc={svc}
            onBack={() => setScr('det')}
            onDone={() => setScr('res')}
            bridge={bridge}
          />
        )}
        {scr === 'res' && card && (
          <Result card={card} amt={amt} svc={svc} onDone={() => { setScr('cards'); fetchCards(); }} />
        )}
        {scr === 'adm' && (
          <Admin onBack={() => setScr('cards')} bridge={bridge} />
        )}
      </div>

      {/* Footer */}
      <div style={{
        display:'flex', justifyContent:'space-between', alignItems:'center',
        padding:'8px 20px 10px', background:'#F4F6FA',
        borderTop:'1px solid #E5E7EB'
      }}>
        <div style={{ width:32 }} />
        <div style={{ width:134, height:5, borderRadius:100, background:'#1C1C1E', opacity:0.15 }} />
        <button onClick={() => setScr('adm')} style={{
          width:32, height:32, borderRadius:'50%', background:'#F0F2F8',
          border:'1px solid #E5E7EB', display:'flex', alignItems:'center',
          justifyContent:'center', cursor:'pointer', fontSize:14, padding:0
        }} title="Админка">📞</button>
      </div>
    </div>
  );
}
