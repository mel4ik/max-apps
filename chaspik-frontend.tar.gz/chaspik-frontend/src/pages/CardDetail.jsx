import React, { useState, useEffect } from 'react';
import { Box, BackBtn } from '../components/Shared';
import { fk, sd, ft, KIND_COLORS } from '../api/helpers';
import * as api from '../api/client';

export default function CardDetail({ card: c, onBack, onTopUp, onBuyService, bridge }) {
  const p = c.parsed || {};
  const kind = p.kind || 'purse';
  const cl = KIND_COLORS[kind] || '#999';
  const pan = c.card_pan || c.n || '';
  const daysLeft = kind === 'abonement' && p.abEnd
    ? Math.max(0, Math.ceil((new Date(p.abEnd) - new Date()) / 86400000))
    : 0;

  const [trips, setTrips] = useState([]);
  const [repls, setRepls] = useState([]);
  const [opsLoading, setOpsLoading] = useState(true);

  useEffect(() => {
    setOpsLoading(true);
    Promise.all([
      api.getTrips(c.id).catch(() => ({ data: [] })),
      api.getReplenishments(c.id).catch(() => ({ data: [] })),
    ]).then(([tripsResp, replsResp]) => {
      // Korona returns { data: [...], paging: {...} }
      setTrips(tripsResp.data || tripsResp.content || []);
      setRepls(replsResp.data || replsResp.content || []);
    }).finally(() => setOpsLoading(false));
  }, [c.id]);

  function handleRefresh() {
    bridge.haptic();
    api.getCardInfo(c.id, true).catch(() => {});
  }

  return (
    <div style={{ padding:'10px 14px 16px' }}>
      <BackBtn onClick={onBack} />

      {/* Градиентная карта */}
      <div style={{
        position:'relative', borderRadius:18, padding:'20px 16px',
        marginBottom:10, overflow:'hidden',
        boxShadow:`0 8px 28px ${cl}44`,
        background:`linear-gradient(135deg,${cl},${cl}CC,${cl}77)`
      }}>
        <div style={{ position:'absolute', top:-35, right:-35, width:120, height:120, borderRadius:'50%', background:'rgba(255,255,255,0.1)' }} />
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', position:'relative', marginBottom:6 }}>
          <p style={{ fontSize:10, fontWeight:700, color:'rgba(255,255,255,0.6)', textTransform:'uppercase', letterSpacing:2, margin:0 }}>
            {p.label || c.ticket_description || 'ЕТК'}
          </p>
          <span style={{ fontSize:10, fontWeight:600, padding:'2px 8px', borderRadius:20, background:'rgba(255,255,255,0.15)', color:'#fff' }}>
            {p.stop ? '⛔ Стоп-лист' : '✓ Активна'}
          </span>
        </div>
        <p style={{ fontSize:14, fontWeight:700, color:'#fff', letterSpacing:1.5, margin:'0 0 2px', position:'relative' }}>
          {pan.replace(/(.{4})/g, '$1 ').trim()}
        </p>
        <p style={{ fontSize:11, color:'rgba(255,255,255,0.5)', margin:'0 0 14px', position:'relative' }}>📍 {c.region || '—'}</p>

        {kind === 'purse' && (
          <div style={{ position:'relative' }}>
            <p style={{ fontSize:10, fontWeight:600, color:'rgba(255,255,255,0.5)', textTransform:'uppercase', letterSpacing:1, margin:'0 0 3px' }}>Баланс</p>
            <p style={{ fontSize:32, fontWeight:800, color:'#fff', margin:0 }}>
              {fk(p.bal)}<span style={{ fontSize:18, fontWeight:600, opacity:0.7 }}> ₽</span>
            </p>
          </div>
        )}

        {kind === 'counter' && (
          <div style={{ position:'relative' }}>
            <p style={{ fontSize:10, fontWeight:600, color:'rgba(255,255,255,0.5)', textTransform:'uppercase', letterSpacing:1, margin:'0 0 3px' }}>Осталось поездок</p>
            <p style={{ fontSize:32, fontWeight:800, color:'#fff', margin:0 }}>
              {p.trips}{p.tripsMax ? <span style={{ fontSize:16, fontWeight:600, opacity:0.6 }}> / {p.tripsMax}</span> : null}
            </p>
            {p.tripsMax && (
              <div style={{ marginTop:8, height:6, borderRadius:3, background:'rgba(255,255,255,0.15)', overflow:'hidden' }}>
                <div style={{ height:'100%', borderRadius:3, background:'#fff', width:Math.round(p.trips/p.tripsMax*100)+'%' }} />
              </div>
            )}
          </div>
        )}

        {kind === 'abonement' && (
          <div style={{ position:'relative' }}>
            <p style={{ fontSize:10, fontWeight:600, color:'rgba(255,255,255,0.5)', textTransform:'uppercase', letterSpacing:1, margin:'0 0 3px' }}>Период действия</p>
            <p style={{ fontSize:26, fontWeight:800, color:'#fff', margin:0 }}>{sd(p.abStart)} – {sd(p.abEnd)}</p>
            <p style={{ fontSize:12, color:'rgba(255,255,255,0.6)', margin:'6px 0 0' }}>
              {daysLeft > 0 ? `Осталось ${daysLeft} дн.` : 'Истёк'}
            </p>
          </div>
        )}

        {p.stale && (
          <p style={{ fontSize:10, color:'rgba(255,255,255,0.4)', margin:'8px 0 0', fontStyle:'italic' }}>
            ⚡ Данные из кэша ({p.source})
          </p>
        )}
      </div>

      {/* Кнопки действий */}
      <div style={{ display:'flex', gap:8, marginBottom:10 }}>
        {c.is_replenishable && (
          <button onClick={onTopUp} style={{
            flex:1, display:'flex', alignItems:'center', justifyContent:'center', gap:5,
            padding:13, fontSize:13, fontWeight:700, fontFamily:'inherit',
            color:'#fff', background:'#FF6B00', border:'none', borderRadius:12, cursor:'pointer'
          }}>↑ Пополнить</button>
        )}
        {(p.svcs && p.svcs.length > 0) && (
          <button onClick={onBuyService} style={{
            flex:1, display:'flex', alignItems:'center', justifyContent:'center', gap:5,
            padding:13, fontSize:13, fontWeight:700, fontFamily:'inherit',
            color:'#fff', background:'#7C3AED', border:'none', borderRadius:12, cursor:'pointer'
          }}>🎫 Купить услугу</button>
        )}
        <button onClick={handleRefresh} style={{
          width:48, display:'flex', alignItems:'center', justifyContent:'center',
          padding:13, fontSize:16, fontFamily:'inherit', color:'#0F1729',
          background:'#fff', border:'1.5px solid #E5E7EB', borderRadius:12, cursor:'pointer'
        }}>↻</button>
      </div>

      {/* Последние операции */}
      <Box>
        <h3 style={{ fontSize:14, fontWeight:700, margin:'0 0 8px' }}>Последние операции</h3>

        {opsLoading && (
          <div style={{ textAlign:'center', padding:'16px 0' }}>
            <div style={{ width:20, height:20, border:'2px solid #E5E7EB', borderTopColor:'#1B6EF3', borderRadius:'50%', margin:'0 auto', animation:'spin 0.6s linear infinite' }} />
          </div>
        )}

        {!opsLoading && repls.map((r, i) => (
          <div key={`r${i}`} style={{ display:'flex', alignItems:'center', gap:10, padding:'9px 0', borderBottom:'1px solid #F0F2F8' }}>
            <div style={{ width:32, height:32, borderRadius:8, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, background:'#E5FBF0' }}>
              <span style={{ color:'#00D26A', fontWeight:700, fontSize:13 }}>↑</span>
            </div>
            <div style={{ flex:1 }}>
              <p style={{ fontSize:13, fontWeight:600, margin:'0 0 1px' }}>
                {r.type_operation === 'REPLENISHMENT' ? 'Пополнение' :
                 r.type_operation === 'MONEY_TRANSFER' ? 'Перевод средств' :
                 r.type_operation || 'Операция'}
              </p>
              <p style={{ fontSize:11, color:'#9CA3AF', margin:0 }}>
                {ft(r.replenishment_date)}
                {r.agent_description ? ` · ${r.agent_description.split(' - ')[0]}` : ''}
              </p>
            </div>
            <p style={{ fontSize:14, fontWeight:700, color:'#00D26A', margin:0 }}>
              +{fk(r.replenishment_sum)} ₽
            </p>
          </div>
        ))}

        {!opsLoading && trips.map((t, i) => (
          <div key={`t${i}`} style={{ display:'flex', alignItems:'center', gap:10, padding:'9px 0', borderBottom:'1px solid #F0F2F8' }}>
            <div style={{ width:32, height:32, borderRadius:8, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, background:'#E8F0FE' }}>
              <span style={{ color:'#1B6EF3', fontWeight:700, fontSize:13 }}>↓</span>
            </div>
            <div style={{ flex:1 }}>
              <p style={{ fontSize:13, fontWeight:600, margin:'0 0 1px' }}>
                {t.route_name || (t.route_num ? `Маршрут ${t.route_num}` : 'Поездка')}
              </p>
              <p style={{ fontSize:11, color:'#9CA3AF', margin:0 }}>
                {ft(t.pass_date || t.trip_date)}
              </p>
            </div>
            <p style={{ fontSize:14, fontWeight:700, margin:0 }}>
              −{fk(t.pass_sum || t.sum_amount || 0)} ₽
            </p>
          </div>
        ))}

        {!opsLoading && !repls.length && !trips.length && (
          <p style={{ fontSize:12, color:'#9CA3AF', textAlign:'center', padding:'16px 0' }}>Нет операций</p>
        )}
      </Box>
    </div>
  );
}
